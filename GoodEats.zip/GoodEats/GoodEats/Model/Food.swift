//
//  Food.swift
//  GoodEats
//
//  Created by Minh Pham on 12/5/23.
//

import Foundation

struct Food: Hashable{
    var name: String
    var rating: Float
    
}
