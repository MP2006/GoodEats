//
//  GoodEatsViewModel.swift
//  GoodEats
//
//  Created by Minh Pham on 12/5/23.
//

import Foundation

class GoodEatsViewModel: ObservableObject{
    
}
